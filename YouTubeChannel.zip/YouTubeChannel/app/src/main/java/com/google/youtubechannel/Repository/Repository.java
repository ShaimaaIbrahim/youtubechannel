package com.google.youtubechannel.Repository;

import android.content.Context;


import com.google.youtubechannel.Model.Entities.ChannelVideos;
import com.google.youtubechannel.R;
import com.google.youtubechannel.Repository.retrofit.ApiConfig;
import com.google.youtubechannel.Repository.retrofit.ApiConstants;
import com.google.youtubechannel.Repository.retrofit.ApiService;

import java.util.Map;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Call;

public final class Repository {

    private static Repository instance;
    private static ApiService service;
    private Context context;

    private Repository(Context context) {
        this.context = context;
        service = ApiConfig.getInstance(context).getService();

    }

    public static Repository getInstance(Context context) {
        if (instance == null)
            instance = new Repository(context);
        return instance;
    }

    public Observable<ChannelVideos> getChannels() {
        String part = context.getString(R.string.part);
        String channelId= context.getString(R.string.channelId);
        String maxResult = context.getString(R.string.maxResult);
        String key = context.getString(R.string.key);

        return service
                .getChannelVideos(part, channelId, maxResult, key)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }




}
