package com.google.youtubechannel.Repository.retrofit;


import com.google.youtubechannel.Model.Entities.ChannelVideos;

import io.reactivex.Observable;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;


public interface ApiService {

    @GET(ApiConstants.END_POINT_SEARCH)
    @FormUrlEncoded
    Observable<ChannelVideos> getChannelVideos(@Field(ApiConstants.PART)
                                       String part, @Field(ApiConstants.CHANNEL_ID)
            String channelId, @Field(ApiConstants.MAX_RESULTS) String maxResults,
                                       @Field(ApiConstants.KEY) String key);



}
