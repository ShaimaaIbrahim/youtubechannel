package com.google.youtubechannel.UI.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.google.youtubechannel.Model.Entities.ChannelVideos;
import com.google.youtubechannel.Model.ViewModels.ChaneelsViewModel;
import com.google.youtubechannel.R;

import java.util.List;

import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.OnBackPressedDispatcherOwner;
import androidx.annotation.NonNull;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

public class MainActivity extends AppCompatActivity {
    ChaneelsViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


       viewModel = ViewModelProviders.of(this).get(ChaneelsViewModel.class);

       viewModel.getChannelVideos().observe(this, new Observer<List<ChannelVideos.Item>>() {
           @Override
           public void onChanged(List<ChannelVideos.Item> items) {
               Log.e("Shaimaa" , items.get(0).getId().toString());
           }
       });

    }
}
