package com.google.youtubechannel.Model.ViewModels;

import android.app.Application;
import android.util.Log;

import com.google.youtubechannel.Model.Entities.BaseViewModel;
import com.google.youtubechannel.Model.Entities.ChannelVideos;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class ChaneelsViewModel extends BaseViewModel {

    public MutableLiveData<List<ChannelVideos.Item>> ChannelsVideosMutable;

    public ChaneelsViewModel(@NonNull Application application) {
        super(application);

        ChannelsVideosMutable = new MutableLiveData<>();
    }

    public LiveData<List<ChannelVideos.Item>> getChannelVideos() {

        getReposity().getChannels().subscribe(new Observer<ChannelVideos>() {
            @Override
            public void onSubscribe(Disposable d) {


            }

            @Override
            public void onNext(ChannelVideos response) {
                if ( response.getItems()!= null)
                    ChannelsVideosMutable.postValue(response.getItems());
            }


            @Override
            public void onError(Throwable e) {

            }


            @Override
            public void onComplete() {

            }

        });
        return ChannelsVideosMutable;
    }
}
