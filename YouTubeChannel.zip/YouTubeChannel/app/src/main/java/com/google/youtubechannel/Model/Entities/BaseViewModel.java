package com.google.youtubechannel.Model.Entities;

import android.app.Application;

import com.google.youtubechannel.Repository.Repository;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class BaseViewModel extends AndroidViewModel {

    public static Repository repository ;

    public BaseViewModel(@NonNull Application application) {
        super(application);
        repository = Repository.getInstance(application);
    }
public static Repository getReposity(){
      return repository;
}
}
